<?php

include_once '../Conexao.php';

class Cargo{
   
    protected $id_cargo;

    /**
     * Get the value of id_cargo
     */ 
    public function getId_cargo()
    {
        return $this->id_cargo;
    }

    /**
     * Set the value of id_cargo
     *
     * @return  self
     */ 
    public function setId_cargo($id_cargo)
    {
        $this->id_cargo = $id_cargo;

        return $this;
    }

    protected $nome;
    
    /**
     * Get the value of nome
     */ 
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     *
     * @return  self
     */ 
    public function setNome($nome)
    {
        $this->nome = $nome;

        return $this;
    }

    public function inserir($dados)
    {

        $nome = $dados['nome'];
        $id_cargo = $dados['id_cargo'];

        $sql = "insert into cargo (nome) values ('$nome')";

        $conexao = new Conexao();
        return $conexao->executar($sql);

    }

    public function alterar($dados){

        $nome = $dados['nome'];
        $id_cargo = $dados['id_cargo'];
    
        $sql = "update cargo set nome = $nome where id_cargo = $id_cargo";

        $conexao = new Conexao();
        $conexao->executar($sql);
    
    }

    public function deletar($id_cargo){

        $sql = "delete from cargo where id_cargo = $id_cargo";

        $conexao = new Conexao();
        $conexao->executar($sql);

    }

    public function recuperarTodos(){

        $sql = "select * from cargo";

        $conexao = new Conexao();
        return $conexao->recuperarTodos($sql);

    }

    public function recuperarPorId($id_cargo){

        $sql = "select * from cargo where id_cargo = $id_cargo";

        $conexao = new Conexao();
        $dados =  $conexao->recuperarTodos($sql);

        $this->id_cargo = $dados[0]['id_cargo'];
        $this->nome = $dados[0]['nome'];

    }

} 

?>