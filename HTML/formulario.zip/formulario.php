<?php
$senha = $_GET["senha"];
$csenha = $_GET["csenha"];
$cpf = $_GET["cpf"];
$cnpj = $_GET["cnpj"];
$nome = $_GET["nome"];
$cargo = $_GET["cargo"];
$status = $_GET["status"];
$sexo = $_GET["sexo"];
$sal = $_GET["salario"];


//Confirmação de senha
if($senha == $csenha){
    echo "As senhas são iguais <br />";
    if($sexo == "F"){
        echo "<b>Prezada Sra.$nome <br /> Você acaba de ser contratada como $cargo <br />Sua situação está $status </b><br />";
    } else {
        echo "<b>Prezado Sr.$nome <br /> Você acaba de ser contratado como $cargo <br />Sua situação está $status </b><br />";
    }
    
} else{
    echo "As senhas não são iguais, favor verificar"; }

//Reajuste Estagiário
if($cargo =="Estagiário"){
    $reajest = (((100*$sal)/100)+$sal);
    echo "<b>Parabéns!Você foi contratado!<br /> 
    Seu novo salário é: R$ $reajest</b>";
}

//Reajuste Gerente    
if($cargo == "Gerente"){
    $reajger = (((50*$sal)/100)+$sal);
    echo "<b>Seu novo salário é: R$ $reajger</b>";
}

//Reajuste Diretor    
if($cargo == "Diretor"){
    $reajdir = (((30*$sal)/100)+$sal);
    echo "<b>Seu novo salário é: R$ $reajdir</b>";
}

//Reajuste Presidente    
if($cargo == "Presidente"){
    $reajpr = (((10 * $sal)/100)+$sal);
    echo "<b>Seu novo salário é: R$ $reajpr</b>";
}
       
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Formulário</title>
</head>
<body>
    <h1 id="formulario">Formulário </h1>
    
    <form action="formulario.php" method="get">

        <label>Tipo de pessoa:</label>  
        <input type="radio"  id="pfis" name="tipop" value="F"/>  <label for="pfis">Pessoa Física</label id="pfis"> 
        <input type="radio"  id="pjur" name="tipop" value="J"/> <label for="pjur">Pessoa Jurídica</label id="pfis"> <br>


        <label for="cpf">CPF:</label><input  placeholder="Preencha o campo..." type="text" name="cpf" id="cpf" /> <br>
        <label for="cnpj">CNPJ</label><input placeholder="Preencha o campo..." type="text" name="cnpj" id="cnpj" /> <br>
        <label for="name">Nome:</label><input required placeholder="Preencha o campo..." type="text" name="nome" id="name" /> <br> 

        <label>Sexo:</label>
        <input type="radio" required id="masculino" name="sexo" value="M"/>  <label for="masculino">Masculino</label id="masculino"> 
        <input type="radio" required id="feminino" name="sexo" value="F"/>   <label for="feminino">Feminino</label id="feminino"> <br>

        <label for="email">Email:</label><input required placeholder="Preencha o campo..." type="email" id="email"/> <br>
        <label for="telefone">Telefone:</label><input required placeholder="Preencha o campo..." type="tel" id="telefone"/> <br> 

        <label>Cargo:</label>
        <select name="cargo" id="carg">
            <option value="Estagiário">Estagiário</option>
            <option value="Gerente">Gerente</option>
            <option value="Diretor">Diretor</option>
            <option value="Presidente">Presidente</option>
         </select> <br>  

         <label for="sal">Salário</label><input name="salario" required placeholder="Preencha o campo..." type="money_format" id="sal"/> <br> 
        
            <fieldset>
                <legend>Endereço</legend>
                    <label for="cep">CEP:</label><input required placeholder="Preencha o campo..." type="text" name="cep" id="cep" /> <br>       
                    <label for="end">Endereço:</label><input required placeholder="Preencha o campo..." type="text" name="end" id="end" /> <br>
                    
                <label>UF:</label> <select name="uf" id="uf">
                    <option value="">Selecione</option>
                    <option value="DF">DF - DISTRITO FEDERAL</option>
                    <option value="SP">SP - SÃO PAULO</option>
                    <option value="RJ">RJ - RIO DE JANEIROL</option>
                     </select> <br>  
                     
                <label>Município:</label> <select  required name="municipio" id="municipio">
                    <option value="">Selecione</option>
                    <option value="1">CEILÂNDIA</option>
                    <option value="2">TAGUATINGA</option>
                    <option value="3">PLANO PILOTO</option>
                    </select> <br> 
            </fieldset>

            <fieldset>
                <legend>Perfil</legend>
                    <input name="perfil[]" id="fin" Value="FIN" type="checkbox" <label for="fin">Financeiro</label> <br>
                    <input name="perfil[]" id="fat" Value="FAT" type="checkbox" <label for="fat">Faturamento</label> <br>
                    <input name="perfil[]" id="cont" Value="CONT" type="checkbox" <label for="cont">Contabilidade</label> <br>
                    <input name="perfil[]" id="rh" Value="RH" type="checkbox" <label for="rh">Recursos Humanos</label> <br>
                </fieldset>
                <label>Status</label>  
                    <input type="radio" id="at" name="status" value="Ativa"/>  <label for="at">Ativo</label id="at"> 
                    <input type="radio" id="inat" name="status" value="Inativa"/> <label for="inat">Inativo</label id="inat">
                    <input type="radio" id="pnd" name="status" value="Pendente"/> <label for="pnd">Pendente</label id="pnd"> <br>
        
                <label for="snh">Senha:</label>  <input required  type="password" name="senha" id="snh" /> <br>         
                <label for="csnh">Confirmação de Senha:</label>  <input required  type="password" name="csenha" id="csnh" /> <br>                 

            <label for="obs">Observação:</label>
            <textarea name="obs" id=obs
            rows="9" cols="30">
            </textarea><br>
        
        <input type="submit" value="Enviar" />            
        <input type="reset" value="Limpar" />
       
       </form>
</body>
</html>
