<?php

$nome = 'Renan Gabriel Ribeiro Farias';
$test = 'letra maiuscula';
$test1 = 'TUDO MAIUSCULO';
$test2 = 'TUDO MINUSCULO';
$test3 = 'nome_completo_pessoa';

/*echo strtolower($test2);*/                   /* Converte todas a letras para minusculo*/
/*echo ucwords($test1);*/                      /* Converte todas as letras em maiusculas*/
/*echo ucfirst ($test);*/                      /* Converte a primeira letra para maiusculo*/
/*echo substr($nome, 0, 5);*/
/*echo strlen($nome);                          /* Retorna a quantia de caracteres*/
/*echo substr($nome, 6, 7);*/                  /* Retorna parte de uma String*/                   
?>
